class scene2 extends Phaser.Scene {
    constructor() {
        super("playGame");
    }

    
}