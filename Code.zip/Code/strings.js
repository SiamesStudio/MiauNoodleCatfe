
var freeGemsText = 'Free'
var spinButtonText = 'Spin'
var shopButton = 'Shop'

//Options Menu
var OptionMenu_title = 'Settings'
var OptionsMenu_text = 'Mute music:'
var OptionsMenu_language = 'Language:'

//Free Gems menu
var FreeGems_Title = 'Gift'
var FreeGems_Text = 'Watch a video to recieve \nextra gems!'
var FreeGems_Button = 'FREE'

//Shop Menu
var Shop_coinsText = 'Coins'
var Shop_diamondsText = 'Diamonds'
var Shop_freeText = 'Free'

function convertToSpanish(){
    freeGemsText = 'Gratis'
    spinButtonText = 'Ruleta'
    shopButton = 'Tienda'

    OptionMenu_title = 'Opciones'
    OptionsMenu_text = 'Sonido: '
    OptionsMenu_language = 'Idioma:'

    FreeGems_Title = 'Regalo'
    FreeGems_Text = 'Mira este anuncion para \nrecibir gemas extra!'
    FreeGems_Button = 'GRATIS'

    Shop_coinsText = 'Monedas'
    Shop_diamondsText = 'Diamantes'
    Shop_freeText = 'Gratis'
    
}

function convertToEnglish(){
    freeGemsText = 'Free'
    spinButtonText = 'Spin'
    shopButton = 'Shop'

    OptionMenu_title = 'Settings'
    OptionsMenu_text = 'Mute music:'
    OptionsMenu_language = 'Language:'

    FreeGems_Title = 'Gift'
    FreeGems_Text = 'Watch a video to recieve \nextra gems!'
    FreeGems_Button = 'FREE'

    Shop_coinsText = 'Coins'
    Shop_diamondsText = 'Diamonds'
    Shop_freeText = 'Free'
}