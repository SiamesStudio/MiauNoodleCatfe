class Loading extends Phaser.Scene {
    constructor(){
        super("Carga")
    }

    preload(){
        this.load.image('loading','assets/UI/loading.jpg');

    }

    create(){
    }

}